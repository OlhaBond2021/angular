export * from "./data.service"; // Сервисы должен экспортироваться до того, как будут экспортироваться компоненты, которые его используют
export * from "./data-list.component";
