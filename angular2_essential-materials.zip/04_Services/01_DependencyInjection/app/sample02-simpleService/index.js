"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./data.service")); // Сервисы должен экспортироваться до того, как будут экспортироваться компоненты, которые его используют
__export(require("./data-list.component"));
//# sourceMappingURL=index.js.map