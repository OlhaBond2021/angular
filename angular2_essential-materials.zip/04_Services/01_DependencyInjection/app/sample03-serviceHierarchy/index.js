"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./counter.service"));
__export(require("./counter1/counter1.component"));
__export(require("./counter2/counter2.component"));
__export(require("./counter3/counter3.component"));
__export(require("./counter-parent/counter-parent.component"));
//# sourceMappingURL=index.js.map