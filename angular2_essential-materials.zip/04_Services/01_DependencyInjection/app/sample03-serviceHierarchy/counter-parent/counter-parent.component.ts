import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "counter-parent",
    templateUrl: "counter-parent.component.html"
})
export class CounterParentComponent{ }