"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./01_ngIf_templates/ng-if.component"));
__export(require("./02_ngSwitch_templates/ng-switch.component"));
__export(require("./03_ngFor_templates/ng-for.component"));
__export(require("./04_temp_ref_var/temp-ref-var.component"));
//# sourceMappingURL=index.js.map