import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "ngswitchtemplate-samples",
    templateUrl: "ng-switch.component.html"
})
export class NgSwitchTemplateComponent {
    choice: string = "1";
}