export * from "./01_ngIf_templates/ng-if.component";
export * from "./02_ngSwitch_templates/ng-switch.component";
export * from "./03_ngFor_templates/ng-for.component";
export * from "./04_temp_ref_var/temp-ref-var.component";
