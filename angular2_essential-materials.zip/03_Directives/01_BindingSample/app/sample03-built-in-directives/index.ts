export * from "./01_ngClass/ng-class.component";
export * from "./02_ngStyle/ng-style.component";
export * from "./03_ngIf/ng-if.component";
export * from "./04_ngSwitch/ng-switch.component";
export * from "./05_ngFor/ng-for.component";