"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./01_ngClass/ng-class.component"));
__export(require("./02_ngStyle/ng-style.component"));
__export(require("./03_ngIf/ng-if.component"));
__export(require("./04_ngSwitch/ng-switch.component"));
__export(require("./05_ngFor/ng-for.component"));
//# sourceMappingURL=index.js.map