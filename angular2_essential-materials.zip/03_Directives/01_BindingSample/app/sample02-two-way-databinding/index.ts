export * from "./01_ngModel/calc.component";
export * from "./02_ngModel_Inside/sample.component";