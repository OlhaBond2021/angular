"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./01_ngModel/calc.component"));
__export(require("./02_ngModel_Inside/sample.component"));
//# sourceMappingURL=index.js.map