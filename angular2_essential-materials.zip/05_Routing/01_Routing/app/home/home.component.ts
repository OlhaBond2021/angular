import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "my-home",
    template: "<h2>This is Home Page</h2>"
})
export class HomeComponent{ }