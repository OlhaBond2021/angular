export class Phrase {
    constructor(public id: number,
        public value: string,
        public language: string) { }
}