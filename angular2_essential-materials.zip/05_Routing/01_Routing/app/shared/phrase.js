"use strict";
var Phrase = (function () {
    function Phrase(id, value, language) {
        this.id = id;
        this.value = value;
        this.language = language;
    }
    return Phrase;
}());
exports.Phrase = Phrase;
//# sourceMappingURL=phrase.js.map