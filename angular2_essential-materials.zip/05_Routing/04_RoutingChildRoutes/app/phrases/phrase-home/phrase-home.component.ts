import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "phrase-home",
    templateUrl: "phrase-home.component.html"
})
export class PhraseHomeComponent{ }