import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "namecard-host",
    templateUrl: "name-card-host.component.html"
})
export class NameCardHostComponent{ }