import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "chapter",
    templateUrl: "chapter.component.html"
})
export class ChapterComponent { }