import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "message-box-host",
    templateUrl: "message-box-host.component.html"
})
export class MessageBoxHostComponent { }