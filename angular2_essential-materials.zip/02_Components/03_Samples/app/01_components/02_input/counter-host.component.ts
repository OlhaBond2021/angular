import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "counter-host",
    templateUrl: "counter-host.component.html"
})
export class CounterHostComponent{ }