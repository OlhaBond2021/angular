import { Component } from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "list-host",
    templateUrl: "list-host.component.html"
})
export class ListHostComponent{ }