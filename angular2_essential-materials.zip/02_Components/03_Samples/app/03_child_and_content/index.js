"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./01_viewChild/block.component"));
__export(require("./01_viewChild/block-host.component"));
__export(require("./02_viewChildren/block2.component"));
__export(require("./02_viewChildren/block2-host.component"));
__export(require("./03_viewContent/item.component"));
__export(require("./03_viewContent/list.component"));
__export(require("./03_viewContent/list-host.component"));
//# sourceMappingURL=index.js.map