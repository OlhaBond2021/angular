"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
// barrel file
// данный файл выполняет re export всех типов данных из JS модулей директории lists
__export(require("./list1/list1.component"));
__export(require("./list2/list2.component"));
__export(require("./lists.module"));
__export(require("./lists.routs"));
//# sourceMappingURL=index.js.map