import { Component } from "@angular/core";

@Component({
    selector: "list-1",
    templateUrl: "app/lists/list1/list1.component.html",
    styleUrls: ["app/lists/list1/list1.component.css"]
})
export class List1Component {
    
}