// barrel file
// данный файл выполняет re export всех типов данных из JS модулей директории lists
export * from "./list1/list1.component";
export * from "./list2/list2.component";
export * from "./lists.module";
export * from "./lists.routs";