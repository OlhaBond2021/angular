"use strict";
var Phrase = (function () {
    function Phrase() {
    }
    return Phrase;
}());
exports.Phrase = Phrase;
//# sourceMappingURL=phrase.js.map