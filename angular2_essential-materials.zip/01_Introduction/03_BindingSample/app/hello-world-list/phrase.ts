export class Phrase {
    value: string;
    language: string;
}