let x: number = 1;
let y: number = 2;
let sum: number;

sum = x + y;
console.log(sum);

// Если убрать комментарий со следующей строки появиться ошибка связанная с тем,
// что переменная sum была объявлена как переменная типа number
//sum = x + y + "hello"; 