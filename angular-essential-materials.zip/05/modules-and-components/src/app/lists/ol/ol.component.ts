import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ol',
  templateUrl: './ol.component.html',
  styleUrls: ['./ol.component.css']
})
export class OlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
