export * from "./education-itvdn/education-itvdn.component";
export * from "./programing/programing.component";
export * from "./trips/trips.component";

