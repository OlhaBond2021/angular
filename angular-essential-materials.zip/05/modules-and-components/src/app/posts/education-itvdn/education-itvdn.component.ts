import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education-itvdn',
  templateUrl: './education-itvdn.component.html',
  styleUrls: ['./education-itvdn.component.css']
})
export class EducationITVDNComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
