import { EducationITVDNComponent, ProgramingComponent, TripsComponent } from './index';

export const route = [
    {path: 'education', component: EducationITVDNComponent},
    {path: 'programing', component: ProgramingComponent},
    {path: 'trips', component: TripsComponent},
];