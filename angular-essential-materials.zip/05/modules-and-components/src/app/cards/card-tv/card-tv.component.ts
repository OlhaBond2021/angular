import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-tv',
  templateUrl: './card-tv.component.html',
  styleUrls: ['./card-tv.component.css']
})
export class CardTVComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
