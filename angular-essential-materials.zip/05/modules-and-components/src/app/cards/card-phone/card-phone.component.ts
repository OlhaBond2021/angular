import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-phone',
  templateUrl: './card-phone.component.html',
  styleUrls: ['./card-phone.component.css']
})
export class CardPhoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
