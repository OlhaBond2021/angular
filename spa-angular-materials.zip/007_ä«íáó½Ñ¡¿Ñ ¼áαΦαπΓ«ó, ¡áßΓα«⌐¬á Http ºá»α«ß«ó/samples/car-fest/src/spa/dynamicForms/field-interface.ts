export interface FieldInput {
    key: string;
    type: string;
    isId: boolean;
    label: string;
    required: boolean;
}