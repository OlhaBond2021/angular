import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'spa-body',
  templateUrl: './spa-body.component.html',
  styleUrls: ['./spa-body.component.css']
})
export class SpaBodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
