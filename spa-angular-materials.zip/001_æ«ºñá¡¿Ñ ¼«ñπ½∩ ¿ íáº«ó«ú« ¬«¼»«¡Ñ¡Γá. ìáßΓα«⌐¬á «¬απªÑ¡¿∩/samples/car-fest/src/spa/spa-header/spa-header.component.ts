import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'spa-header',
  templateUrl: './spa-header.component.html',
  styleUrls: ['./spa-header.component.css']
})
export class SpaHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
