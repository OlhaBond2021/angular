export interface Car {
    id: number;
    name: string;
    model: string;
    price: number;
}