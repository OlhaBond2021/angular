import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car-maint',
  templateUrl: './car-maint.component.html',
  styleUrls: ['./car-maint.component.css']
})
export class CarMaintComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
